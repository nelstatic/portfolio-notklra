Hi!

Thank you for downloading my f/Stop font.

To install: unzip to C:\windows\fonts or C:\winnt\fonts (depends on which version of Windows you are using).

That's it - the font is installed! You will need to restart any open applications to beable to use the font in that app.

This font carries a $10 shareware fee. This is to help cover my cost of developing and supporting this, and my other typefaces. Please don't be a jerk and use it without paying. You can send gifts instead of money if you like.

You can pay via PayPal - make the payment to fonts@jenniferdickert.com

To pay the old fashioned way, e-mail me for my address: fonts@jenniferdickert.com

I hope you enjoy this font! If you use it for anything cool, please let me know! Also, send me an example!!!!

-Jen

http://www.jenniferdickert.com

fonts@jenniferdickert.com
